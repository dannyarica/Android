package com.hintdesk.De_De_Dict.interfaces.dao;

import android.content.Context;

/**
 * Created with IntelliJ IDEA.
 * User: ServusKevin
 * Date: 6/1/13
 * Time: 1:20 PM
 * To change this template use File | Settings | File Templates.
 */
public interface IBaseDAO {
    void setContext(Context context);
}
