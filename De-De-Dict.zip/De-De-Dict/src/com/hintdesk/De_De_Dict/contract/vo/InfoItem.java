package com.hintdesk.De_De_Dict.contract.vo;

import android.provider.BaseColumns;

/**
 * Created with IntelliJ IDEA.
 * User: ServusKevin
 * Date: 6/1/13
 * Time: 8:52 AM
 * To change this template use File | Settings | File Templates.
 */
public interface InfoItem extends BaseColumns {
    public static String TABLE =null;
    public static String[] COLUMNS =null;
}
