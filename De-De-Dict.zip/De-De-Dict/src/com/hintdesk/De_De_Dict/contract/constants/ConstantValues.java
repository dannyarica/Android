package com.hintdesk.De_De_Dict.contract.constants;

/**
 * Created with IntelliJ IDEA.
 * User: ServusKevin
 * Date: 6/2/13
 * Time: 9:10 AM
 * To change this template use File | Settings | File Templates.
 */
public class ConstantValues {
    public static final String EXTRA_WORD = "EXTRA_WORD";

}
